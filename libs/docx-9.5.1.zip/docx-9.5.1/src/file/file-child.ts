import { XmlComponent } from "@file/xml-components";

export class FileChild extends XmlComponent {
    public readonly fileChild = Symbol();
}
