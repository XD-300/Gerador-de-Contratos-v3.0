import { XmlComponent } from "@file/xml-components";

export class FootnoteRef extends XmlComponent {
    public constructor() {
        super("w:footnoteRef");
    }
}
