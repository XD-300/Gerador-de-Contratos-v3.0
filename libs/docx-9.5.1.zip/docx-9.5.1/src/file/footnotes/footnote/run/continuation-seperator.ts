import { XmlComponent } from "@file/xml-components";

export class ContinuationSeperator extends XmlComponent {
    public constructor() {
        super("w:continuationSeparator");
    }
}
