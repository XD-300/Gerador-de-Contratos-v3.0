import { BuilderElement, XmlComponent } from "@file/xml-components";

export const createNoFill = (): XmlComponent => new BuilderElement({ name: "a:noFill" });
