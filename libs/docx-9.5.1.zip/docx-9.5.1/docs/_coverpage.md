<img src="https://i.imgur.com/37uBGhO.gif" alt="drawing" style="width:200px;"/>

> Easily generate and modify .docx files with JS/TS. Works for Node and on the Browser. :100:

-   Simple, declarative API
-   80+ usage examples
-   Battle tested, mature, 100% coverage (yes, every line is tested)

[GitHub](https://github.com/dolanmiu/docx)
[Get Started](#Welcome)
