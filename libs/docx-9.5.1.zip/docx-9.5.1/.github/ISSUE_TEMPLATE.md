# Thank you for raising an issue to `docx`

Please do not raise an issue unless it is an **issue**.

-   Is your issue a feature request? Are you giving ideas to the community? Are you asking for help? Please raise a ticket in the `Discussions` section:

    https://github.com/dolanmiu/docx/discussions

-   Is your issue a previously asked? Please respond to that thread instead
